from pydantic import BaseModel

class PostRequest(BaseModel):
    platform: str
    post_text: str


class ReplyRequest(BaseModel):
      platform: str
      original_text: str
      tone: str
      sentiment: str
      creativity: float
  