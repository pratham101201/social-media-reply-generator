from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_reply_endpoint():
    response = client.post("/reply", json={"platform": "linkedin", "post_text": '''Leadership.
What does it actually mean?

It’s navigating through uncertainty with confidence and intention.
Leadership is about direction — leadership is about SERVING, not controlling; true leaders never micromanage.

It’s not about when you get there, but how you get there — with your leader supporting You.
The journey is about You.
The journey defines You.

Trust and being trusted - always a two way street; that’s leadership at its core.

Pick a good leader.'''})
    assert response.status_code == 200
    assert "reply" in response.json()