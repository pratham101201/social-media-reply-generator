'''import os
from  openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def generate_reply(platform: str, post_text: str) -> str:
    prompt = f"""
You are a professional social media assistant.

Platform: {platform}
Original Post: \"{post_text}\"

Generate a human-like, natural, and engaging reply that fits the tone and context of this platform. Avoid sounding robotic or overly generic.
"""
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You write authentic, human-like social media replies."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=100
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error generating reply: {str(e)}"'''


# services/reply_generator.py

from transformers import pipeline
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
# Load a Hugging Face model — GPT2 is small and runs locally
# Ensure resources are available
nltk.download('vader_lexicon')

# Initialize Sentiment Analyzer
sia = SentimentIntensityAnalyzer()

def analyze_sentiment(post_text):
    score = sia.polarity_scores(post_text)
    if score['compound'] >= 0.3:
        return 'positive'
    elif score['compound'] <= -0.3:
        return 'negative'
    else:
        return 'neutral'
generator = pipeline("text-generation", model="gpt2")
classifier = pipeline("text-classification", model="distilbert-base-uncased-finetuned-sst-2-english")
def generate_reply(platform: str, post_text: str) -> str:
    analyzer = SentimentIntensityAnalyzer()
    score = analyzer.polarity_scores(post_text)['compound']
    if score > 0.05 :
        tone="positive"
    elif score < -0.05:
        tone="negative"
    else:
        tone="neutral"
    print(f"Tone detected: {tone}")
    # Use the classifier to get the intent
    intent = classifier(post_text)[0]['label']
    if intent == "promise":
        intent = "commitment"
    elif intent == "question":
        intent = "inquiry"
    elif intent == "statement":
        intent = "statement"
    else:
        intent = "general"

    print(f"Intent detected: {intent}") 
    prompt = f"""
        You are a professional social media assistant.

        Platform: {platform}
        Original Post: \"{post_text}\"

        Generate a human-like, natural, and engaging reply that fits The {tone},{intent} and context of this platform.
        Avoid sounding robotic or overly generic and repetative text.Don't give one word answer .There should be meaningfull sentence or word.Keep the reply under 60 words.
        Reply:
        """
    try:
        response = generator(prompt, max_length=200, num_return_sequences=1)
        return response[0]["generated_text"].split("Reply:")[-1].strip()
    except Exception as e:
        return f"Error generating reply: {str(e)}"
    



