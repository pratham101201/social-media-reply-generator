'''import os
import anthropic

# Set your API key (use environment variable or hardcode temporarily for testing)
client = anthropic.Anthropic(
    api_key=os.getenv("ANTHROPIC_API_KEY")  # or replace with your key as a string
)

def generate_reply(platform: str, post_text: str) -> str:
    print(f"Generating reply for platform: {platform}")
    prompt = f"""
You are a professional social media assistant.

Platform: {platform}
Original Post: "{post_text}"

Generate a human-like, natural, and engaging reply that fits the tone and context of this platform.
Avoid sounding robotic or overly generic. Keep the reply under 50 words.
Reply:"""

    try:
        response = client.messages.create(
            model="claude-3-haiku-20240307",  # or claude-3-sonnet, or claude-3-opus
            max_tokens=100,
            temperature=0.7,
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )
        return response.content[0].text.strip()
    except Exception as e:
        return f"Error generating reply: {str(e)}"'''

from transformers import pipeline
import os




# Load emotion and sentiment models
emotion_classifier = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base", top_k=1)
sentiment_classifier = pipeline("sentiment-analysis")  # Simple positive/negative

def analyze_post(post_text):
    tone = emotion_classifier(post_text)[0][0]['label']  # e.g., "joy", "anger"
    sentiment = sentiment_classifier(post_text)[0]['label'].lower()  # "positive" or "negative"

    # Basic intent detection via keyword heuristics (customize as needed)
    lower_text = post_text.lower()
    if any(w in lower_text for w in ["will make", "we promise", "we commit", "we’ll ensure", "we will", "committed to", "vow", "pledge"]):
        intent = "promise"
    elif any(w in lower_text for w in ["help", "any advice", "suggestions", "can someone"]):
        intent = "asking for help"
    elif any(w in lower_text for w in ["won", "got promoted", "achieved", "launched"]):
        intent = "sharing a win"
    elif any(w in lower_text for w in ["this sucks", "hate", "frustrated", "ugh"]):
        intent = "venting"
    elif any(w in lower_text for w in ["story", "once", "experience"]):
        intent = "telling a story"
    else:
        intent = "general sharing"

    return tone, sentiment, intent

# You can replace with another model suited for text generation
generator = pipeline("text-generation", model="gpt2")  # Lightweight and fast for local use

def generate_prompt(platform, post_text, tone, sentiment, intent):
    # Choose persona
    if platform.lower() == "twitter":
        persona = "casual and witty"
    elif platform.lower() == "instagram":
        persona = "warm, expressive, maybe use emojis"
    elif platform.lower() == "linkedin":
        persona = "professional and supportive"
    else:
        persona = "friendly"

    # Final prompt passed to LLM
    return f"""
You are a smart, human-like assistant writing social media replies.

Platform: {platform}
Detected Tone: {tone}
Sentiment: {sentiment}
Intent: {intent}
Persona: {persona}

Original Post: "{post_text}"

Write a short, natural, engaging reply (under 50 words) that fits the platform tone and post context.
Avoid generic or robotic language.
Reply:
"""