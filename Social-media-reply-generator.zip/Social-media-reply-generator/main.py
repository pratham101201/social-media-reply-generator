from fastapi import FastAPI, HTTPException
from models.schemas import PostRequest
from services.reply_generator import generate_reply
from firebase_admin import firestore, credentials, initialize_app
from datetime import datetime
import os

# Firebase init
cred = credentials.Certificate("use your firebase credentials file")
initialize_app(cred)
db = firestore.client()
collection = db.collection("replies")

app = FastAPI()

@app.post("/reply")
async def create_reply(request: PostRequest):
    try:
        print(f"Received request: {request.platform}, {request.post_text}")
        reply = generate_reply(request.platform, request.post_text)

        collection.add({
            "platform": request.platform,
            "post_text": request.post_text,
            "generated_reply": reply,
            "timestamp": datetime.utcnow()
        })
        return {"reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    




