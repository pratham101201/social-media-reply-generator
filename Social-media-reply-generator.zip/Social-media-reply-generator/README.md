# Social Media Reply Generator API

## Setup
1. Install dependencies:
```bash
pip install -r requirements.txt
```
2. Add `firebase_credentials.json` to project root
3. Set your OpenAI API key:
```bash
export OPENAI_API_KEY="your-api-key-here"
```
4. Run API:
```bash
uvicorn main:app --reload
```

## API Usage
**POST /reply**
```json
{
  "platform": "LinkedIn",
  "post_text": "Proud to announce my new position at XYZ Corp."
}
```
**Response:**
```json
{
  "reply": "Congratulations on your new role at XYZ Corp! Wishing you great success."
}
```

## Notes
- Uses OpenAI GPT (gpt-3.5-turbo) to generate replies
- Environment variable `OPENAI_API_KEY` must be set
- Firebase credentials should not be committed (add to `.gitignore`)
